create
    definer = root@localhost procedure DELETE_USER(IN user_id int)
BEGIN 
DELETE FROM USERS
WHERE users.id = user_id;
END;

