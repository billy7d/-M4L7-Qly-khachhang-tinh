create
    definer = root@localhost procedure UPDATE_USER(IN user_id int, IN user_name varchar(255),
                                                   IN user_country varchar(255))
BEGIN
UPDATE users
SET
users.id = user_id,
users.name = user_name,
users.country = user_country
where users.id = user_id;
END;

